package com.example.pdatta.salary;

//import android.net.http.RequestQueue;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.RequestQueue;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private TextView mTextViewResult;
    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextViewResult = findViewById(R.id.text_view_result);
        Button buttonParse = findViewById(R.id.button_parse);

        mQueue = Volley.newRequestQueue(this);
        jsonParse();
        buttonParse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                jsonParse();
            }
        });
    }

    private void jsonParse(){

        // --------- Reference ---------
        // https://www.youtube.com/watch?v=y2xtLqP8dSQ
        //This app will keep you updated with Top 5 news headlines. No adds and graphics. Less memory required.

        mTextViewResult.setText("");
        String url = "https://newsapi.org/v2/top-headlines?sources=the-times-of-india&apiKey=096359f0fc2b41ada64eb65c336e420e";//"https://api.myjson.com/bins/kp9wz";
        //mTextViewResult.append("Working Fine.\n\n");
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    //mTextViewResult.append("Working Fine.\n\n");
                    JSONArray jsonArray = response.getJSONArray("articles");

                    for(int i =0; i<5; i++){//jsonArray.length()
                        JSONObject employee = jsonArray.getJSONObject(i);

                        String title = employee.getString("title");
                        //int age = employee.getInt("age");
                        //String mail = employee.getString("mail");

                        mTextViewResult.append(title+"\n\n");
                    }

                }catch(JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mTextViewResult.append("Error : "+error.getMessage()+"\n\n");
                error.printStackTrace();
            }
        });

    mQueue.add(request);
    }
}
